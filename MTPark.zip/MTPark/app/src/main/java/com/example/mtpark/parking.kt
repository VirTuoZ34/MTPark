package com.example.mtpark


 class Parking(var name: String, var status: String, var free: Int){
    constructor(): this("Nan", "Nan", 0)
}